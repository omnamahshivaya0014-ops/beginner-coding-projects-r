"""A simple command-line task tracker using only the Python standard library."""
import json
from pathlib import Path

DATA_FILE = Path(__file__).with_name("tasks.json")


def load_tasks():
    """Load tasks from disk; return an empty list if no file exists yet."""
    if not DATA_FILE.exists():
        return []
    try:
        with DATA_FILE.open("r", encoding="utf-8") as file:
            data = json.load(file)
        return data if isinstance(data, list) else []
    except (json.JSONDecodeError, OSError):
        print("Warning: Could not read tasks.json. Starting with an empty task list.")
        return []


def save_tasks(tasks):
    """Save tasks to disk in readable JSON format."""
    with DATA_FILE.open("w", encoding="utf-8") as file:
        json.dump(tasks, file, indent=2, ensure_ascii=False)


def next_task_id(tasks):
    """Return the next available integer ID."""
    return max((task.get("id", 0) for task in tasks), default=0) + 1


def add_task(tasks, title):
    """Add a task with a non-empty title and return it."""
    title = title.strip()
    if not title:
        raise ValueError("Task title cannot be empty.")
    task = {"id": next_task_id(tasks), "title": title, "completed": False}
    tasks.append(task)
    return task


def complete_task(tasks, task_id):
    """Mark a task complete. Return True if found, otherwise False."""
    for task in tasks:
        if task.get("id") == task_id:
            task["completed"] = True
            return True
    return False


def delete_task(tasks, task_id):
    """Delete a task by ID. Return True if found, otherwise False."""
    for index, task in enumerate(tasks):
        if task.get("id") == task_id:
            del tasks[index]
            return True
    return False


def show_tasks(tasks):
    if not tasks:
        print("No tasks yet. Add one to get started.")
        return
    for task in tasks:
        status = "✓" if task.get("completed") else " "
        print(f'[{status}] #{task["id"]}: {task["title"]}')


def ask_for_id():
    try:
        return int(input("Task ID: ").strip())
    except ValueError:
        print("Please enter a valid whole number.")
        return None


def main():
    tasks = load_tasks()
    while True:
        print("\n=== CLI Task Tracker ===")
        print("1. Add task")
        print("2. List tasks")
        print("3. Mark task complete")
        print("4. Delete task")
        print("5. Exit")
        choice = input("Choose an option: ").strip()

        if choice == "1":
            title = input("Task title: ")
            try:
                task = add_task(tasks, title)
                save_tasks(tasks)
                print(f'Added task #{task["id"]}.')
            except ValueError as error:
                print(error)
        elif choice == "2":
            show_tasks(tasks)
        elif choice == "3":
            task_id = ask_for_id()
            if task_id is not None:
                if complete_task(tasks, task_id):
                    save_tasks(tasks)
                    print("Task marked complete.")
                else:
                    print("No task found with that ID.")
        elif choice == "4":
            task_id = ask_for_id()
            if task_id is not None:
                if delete_task(tasks, task_id):
                    save_tasks(tasks)
                    print("Task deleted.")
                else:
                    print("No task found with that ID.")
        elif choice == "5":
            print("Good luck with your coding journey!")
            break
        else:
            print("Choose a number from 1 to 5.")


if __name__ == "__main__":
    main()
