"""Unit tests for the task tracker."""
import unittest
from task_tracker import add_task, complete_task, delete_task, next_task_id


class TaskTrackerTests(unittest.TestCase):
    def test_add_task_strips_title_and_assigns_id(self):
        tasks = []
        task = add_task(tasks, "  Learn Python  ")
        self.assertEqual(task, {"id": 1, "title": "Learn Python", "completed": False})

    def test_add_empty_title_is_rejected(self):
        with self.assertRaises(ValueError):
            add_task([], "   ")

    def test_ids_increase(self):
        tasks = [{"id": 2, "title": "Existing", "completed": False}]
        self.assertEqual(next_task_id(tasks), 3)

    def test_complete_task(self):
        tasks = [{"id": 1, "title": "Read docs", "completed": False}]
        self.assertTrue(complete_task(tasks, 1))
        self.assertTrue(tasks[0]["completed"])

    def test_complete_missing_task(self):
        self.assertFalse(complete_task([], 999))

    def test_delete_task(self):
        tasks = [{"id": 1, "title": "Read docs", "completed": False}]
        self.assertTrue(delete_task(tasks, 1))
        self.assertEqual(tasks, [])

    def test_delete_missing_task(self):
        self.assertFalse(delete_task([], 999))


if __name__ == "__main__":
    unittest.main()
