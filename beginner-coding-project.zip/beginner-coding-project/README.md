# Beginner Coding Project: CLI Task Tracker

A small command-line task tracker built with Python. It lets you add tasks, list them, mark them complete, and delete them. Tasks are saved locally in a JSON file.

## Features
- Add a task
- List tasks with status and ID
- Mark a task complete
- Delete a task
- Store tasks in `tasks.json`
- No third-party packages required

## Requirements
- Python 3.9 or newer

## Run it
```bash
python task_tracker.py
```

On some systems, use `python3 task_tracker.py`.

## Example
```text
=== CLI Task Tracker ===
1. Add task
2. List tasks
3. Mark task complete
4. Delete task
5. Exit
Choose an option: 1
Task title: Learn Python
Added task #1.
```

## Project structure
```text
beginner-coding-project/
├── task_tracker.py
├── test_task_tracker.py
├── README.md
├── LICENSE
└── .gitignore
```

## Learning goals
This project practices functions, lists and dictionaries, JSON file handling, input validation, and unit testing.

## Roadmap
- Add due dates
- Add priorities
- Filter completed tasks
- Add a simple graphical interface

## Honest contribution note
This is a starter project intended for learning. Before presenting it as your own work, read and understand the code, run it, and make meaningful improvements yourself. Creating this repository alone does not establish eligibility for any open-source contributor program.
